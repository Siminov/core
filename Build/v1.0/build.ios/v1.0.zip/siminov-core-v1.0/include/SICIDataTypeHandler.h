/// 
/// [SIMINOV FRAMEWORK]
/// Copyright [2015] [Siminov Software Solution LLP|support@siminov.com]
///
/// Licensed under the Apache License, Version 2.0 (the "License");
/// you may not use this file except in compliance with the License.
/// You may obtain a copy of the License at
///
///     http://www.apache.org/licenses/LICENSE-2.0
///
/// Unless required by applicable law or agreed to in writing, software
/// distributed under the License is distributed on an "AS IS" BASIS,
/// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
/// See the License for the specific language governing permissions and
/// limitations under the License.
///


/**
 * Exposes convert API which is responsible to provide column data type based on java variable data type.
 */

#import <Foundation/Foundation.h>

/*
 * SQLite Data Types
 */

/** SQLite Integer Data Type */
static NSString * const SQLITE_INTEGER_DATA_TYPE = @"INTEGER";

/**
 * SQLite Text Data Type
 */
static NSString * const SQLITE_TEXT_DATA_TYPE = @"TEXT";

/**
 * SQLite Real Data Type
 */
static NSString * const SQLITE_REAL_DATA_TYPE = @"REAL";

/**
 * SQLite None Data Type
 */
static NSString * const SQLITE_NONE_DATA_TYPE = @"NONE";

/**
 * SQLite Numeric Data Type
 */
static NSString * const SQLITE_NUMERIC_DATA_TYPE = @"NUMERIC";


/*
 * Java Data Types
 */

/**
 * Java Int Primitive Data Type
 */
static NSString * const OBJECTIVE_C_INT_PRIMITIVE_DATA_TYPE = @"int";

/**
 * Java Integer Data Type
 */
static NSString * const OBJECTIVE_C_INTEGER_DATA_TYPE = @"NSInteger";

/**
 * Java Long Primitive Data Type
 */
static NSString * const OBJECTIVE_C_LONG_PRIMITIVE_DATA_TYPE = @"long";

/**
 * Java Long Data Type
 */
static NSString * const OBJECTIVE_C_LONG_DATA_TYPE = @"";

/**
 * Java Float Primitive Data Type
 */
static NSString * const OBJECTIVE_C_FLOAT_PRIMITIVE_DATA_TYPE = @"float";

/**
 * Java Float Data Type
 */
static NSString * const OBJECTIVE_C_FLOAT_DATA_TYPE = @"";

/**
 * Java Double Primitive Data Type
 */
static NSString * const OBJECTIVE_C_DOUBLE_PRIMITIVE_DATA_TYPE = @"double";

/**
 * Java Double Data Type
 */
static NSString * const OBJECTIVE_C_DOUBLE_DATA_TYPE = @"";

/**
 * Java Boolean Primitive Data Type
 */
static NSString * const OBJECTIVE_C_BOOLEAN_PRIMITIVE_DATA_TYPE = @"BOOL";

/**
 * Java Boolean Data Type
 */
static NSString * const OBJECTIVE_C_BOOLEAN_DATA_TYPE = @"";

/**
 * Java Char Primitive Data Type
 */
static NSString * const OBJECTIVE_C_CHAR_PRIMITIVE_DATA_TYPE = @"char";

/**
 * Java Character Data Type
 */
static NSString * const OBJECTIVE_C_CHARACTER_DATA_TYPE = @"";

/**
 * Java String Data Type
 */
static NSString * const OBJECTIVE_C_STRING_DATA_TYPE = @"NSString";

/**
 * Java Byte Primitive Data Type
 */
static NSString * const OBJECTIVE_C_BYTE_PRIMITITVE_DATA_TYPE = @"";

/**
 * Java Byte Data Type
 */
static NSString * const OBJECTIVE_C_BYTE_DATA_TYPE = @"";

/**
 * Java Void Primitive Data Type
 */
static NSString * const OBJECTIVE_C_VOID_PRIMITITVE_DATA_TYPE = @"void";

/**
 * Java Void Data Type
 */
static NSString * const OBJECTIVE_C_VOID_DATA_TYPE =@"";

/**
 * Java Short Primitive Data Type
 */
static NSString * const OBJECTIVE_C_SHORT_PRIMITITVE_DATA_TYPE = @"short";

/**
 * Java Short Data Type
 */
static NSString * const OBJECTIVE_C_SHORT_DATA_TYPE =@"";


/*
 * JavaScript Data Types
 */

/**
 * JavaScript String Data Type
 */
static NSString * const JAVASCRIPT_STRING_DATA_TYPE = @"String";

/**
 * JavaScript Number Data Type
 */
static NSString * const JAVASCRIPT_NUMBER_DATA_TYPE = @"Number";

/**
 * JavaScript Boolean Data Type
 */
static NSString * const JAVASCRIPT_BOOLEAN_DATA_TYPE = @"Boolean";


@protocol SICIDataTypeHandler <NSObject>

/** Converts objective c variable data type to database column data type.
 
 @param dataType Java variable data type.
 @return column data type.
 */
- (NSString *)convert:(NSString *)dataType;

@end
