///
/// [SIMINOV FRAMEWORK]
/// Copyright [2015] [Siminov Software Solution LLP|support@siminov.com]
///
/// Licensed under the Apache License, Version 2.0 (the "License");
/// you may not use this file except in compliance with the License.
/// You may obtain a copy of the License at
///
///     http://www.apache.org/licenses/LICENSE-2.0
///
/// Unless required by applicable law or agreed to in writing, software
/// distributed under the License is distributed on an "AS IS" BASIS,
/// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
/// See the License for the specific language governing permissions and
/// limitations under the License.
///


#import <Foundation/Foundation.h>
#import "SICDatabaseMappingDescriptor.h"

/** Exposes methods to GET and SET Library Descriptor information as per define in LibraryDescriptor.core.xml file by application.
 
 Example:
 
     <library-descriptor>
        
         <!-- General Properties Of Library -->
         
         <!-- Mandatory Field -->
         <property name="name">name_of_library</property>
         
         <!-- Optional Field -->
         <property name="description">description_of_library</property>
            
         
         
         <!-- Database Mappings Needed Under This Library Descriptor -->
         
         <!-- Optional Field -->
            <!-- Database Mapping Descriptors -->
         <database-mapping-descriptors>
            <database-mapping-descriptor>name_of_database_descriptor.full_path_of_database_mapping_descriptor_file</database-mapping-descriptor>
         </database-mapping-descriptors>
     
    </library-descriptor>
 */
@interface SICLibraryDescriptor : NSObject <SICIDescriptor> {
    NSMutableDictionary *properties;
    
    NSMutableArray *databaseMappingPaths;
    
    NSMutableDictionary *databaseMappingsBasedOnTableName;
    NSMutableDictionary *databaseMappingsBasedOnClassName;
    NSMutableDictionary *databaseMappingsBasedOnPath;
}

/**
 * Get library name.
 */
- (NSString *)getName;

/**
 * Set library name as per defined in LibraryDescriptor.core.xml
 * @param name Name of Library.
 */
- (void)setName:(NSString * const)name;

/**
 * Get descriptor as per defined in LibraryDescriptor.core.xml
 * @return
 */
- (NSString *)getDescription;

/**
 * Set description as per defined in LibraryDescritor.core.xml
 * @param description Description of Library.
 */
- (void)setDescription:(NSString * const)description;

/**
 * Check whether database mapping object exists or not, based on table name.
 * @param tableName Name of table.
 * @return TRUE: If database mapping exists, FALSE: If database mapping does not exists.
 */
- (BOOL)containsDatabaseMappingBasedOnTableName:(NSString * const)tableName;

/**
 * Check whether database mapping object exists or not, based on POJO class name.
 * @param className POJO class name.
 * @return TRUE: If database mapping exists, FALSE: If database mapping does not exists.
 */
- (BOOL)containsDatabaseMappingBasedOnClassName:(NSString * const)className;

/**
 * Get all database mapping paths as per defined in DatabaseDescriptor.si.xml file.
 * @return Iterator which contain all database mapping paths.
 */
- (NSEnumerator *)getDatabaseMappingPaths;

/** Add database mapping path as per defined in DatabaseDescriptor.core.xml file.

 EXAMPLE:
 
     <database-descriptor>
        <database-mappings>
            <database-mapping path="Liquor-Mappings/Liquor.xml" />
            <database-mapping path="Liquor-Mappings/LiquorBrand.xml" />
        </database-mappings>
     </database-descriptor>
 
 @param databaseMappingPath Database Mapping Path.
 */
- (void)addDatabaseMappingPath:(NSString * const)databaseMappingPath;

/**
 * Get all database mapping objects contained.
 * @return All database mapping objects.
 */
- (NSEnumerator *)getDatabseMappings;

/**
 * Get database mapping object based on table name.
 * @param tableName Name of table.
 * @return DatabaseMapping object based on table name.
 */
- (SICDatabaseMappingDescriptor *)getDatabseMappingBasedOnTableName:(NSString * const)tableName;

/**
 * Get database mapping object based on POJO class name.
 * @param className POJO class name.
 * @return Database Mapping object.
 */
- (SICDatabaseMappingDescriptor *)getDatabseMappingBasedOnClassName:(NSString * const)className;

/**
 * Get database mapping object based on path.
 * @param libraryDatabaseMappingPath Library Database path as per defined in Database Descriptor.xml file.
 * @return Database Mapping object.
 */
- (SICDatabaseMappingDescriptor *)getDatabseMappingBasedOnPath:(NSString * const)libraryDatabaseMappingPath;

/**
 * Add database mapping object in respect to database mapping path.
 * @param libraryDatabaseMappingPath Library Database Mapping Path.
 * @param databaseMappingDescriptor Database Mapping object.
 */
- (void)addDatabaseMapping:(NSString * const)libraryDatabaseMappingPath databaseMappingDescriptor:(SICDatabaseMappingDescriptor * const)databaseMappingDescriptor;

/**
 * Remove database mapping object based on database mapping path.
 * @param databaseMappingPath Database Mapping Path.
 */
- (void)removeDatabaseMappingBasedOnPath:(NSString * const)databaseMappingPath;

/**
 * Remove database mappping object based on POJO class name.
 * @param className POJO class name.
 */
- (void)removeDatabaseMappingBasedOnClassName:(NSString * const)className;

/**
 * Remove database mapping object based on table name.
 * @param tableName Name of table.
 */
- (void)removeDatabaseMappingBasedOnTableName:(NSString * const)tableName;

/**
 * Remove database mapping object based on database mapping object.
 * @param databaseMapping Database Mapping object which needs to be removed.
 */
- (void)removeDatabaseMapping:(SICDatabaseMappingDescriptor * const)databaseMapping;

/**
 * Get all database mapping objects in sorted order. The order will be as per defined in DatabaseDescriptor.si.xml file.
 * @return Iterator which contains all database mapping objects.
 */
- (NSEnumerator *)orderedDatabaseMappings;

@end
